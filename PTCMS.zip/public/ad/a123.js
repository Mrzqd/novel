var r=Math.random(),n=0,l=[];
for(var i=0;i<l.length;i++){if (r>n&&r<=n+l[i].w) {eval(l[i].f);break;}n+=l[i].w;}